// Generated from Rails OpenAPI by scripts/generate-paid-membership-client.cjs.
import { makeRequest, ApiDataResponse } from './apiClient';

export type ContinuousPaidMembership = { "continuousPaidMembershipMonths": number; "revision": number; "estimated": boolean; };
export type IncreaseContinuousPaidMembership = { "continuousPaidMembershipMonths": number; "expectedRevision": number; "reason": string; };

export function getContinuousPaidMembership(params: { id: string;  }): Promise<ApiDataResponse<ContinuousPaidMembership>> {
  return makeRequest<ContinuousPaidMembership>("GET", "/members/{id}/continuous_paid_membership".replace('{id}', encodeURIComponent(params.id)), undefined);
}

export function increaseContinuousPaidMembership(params: { id: string; body: IncreaseContinuousPaidMembership; }): Promise<ApiDataResponse<ContinuousPaidMembership>> {
  return makeRequest<ContinuousPaidMembership>("PUT", "/admin/members/{id}/continuous_paid_membership".replace('{id}', encodeURIComponent(params.id)), params.body);
}
